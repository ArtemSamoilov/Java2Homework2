/**
 * Java 2 Homework 2 extended
 *
 * Это экспериментальный вариант кода который я создал по заданию из методички
 *
 * @author Artem Samoilov
 * @version dated Dec 24, 2017
 * @link 
 */

import java.util.Scanner;

class Test{
	
	static int sum = 0;

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
				
		System.out.println("Enter matrix dimension: ");
		int N = sc.nextInt();
		
		System.out.println("Enter matrix elements: ");
		String[][] arr = new String[N][N];
		for(int i = 0; i < N; i++)
			for(int j = 0; j < N; j++)
				arr[i][j] = sc.nextLine();
		
        try{
			numExc(N);
        }catch(MyArraySizeException ex){
            System.out.println(ex.getMessage());
        }
		
		for (int i = 0; i < N; i++){
            for (int j = 0; j < N; j++) {
                try {
                    convertExc(arr, i, j);
                } catch (MyArrayDataException e) {
                    System.out.println("Data input failure " + e.i + "x" + e.j);
                }
            }
        }
        System.out.println("Sum of all array digits: " + sum);
	}
	
	public static void numExc(int N) throws MyArraySizeException{
        if(N != 4) throw new MyArraySizeException("Array size should be 4", N);
	}
	
	static void convertExc(String[][] arr, int i, int j) throws MyArrayDataException{
                try {
                    sum += Integer.parseInt(arr[i][j]);
                } catch (NumberFormatException e) {
                    throw new MyArrayDataException(i, j);
        }
    }
}
 
class MyArraySizeException extends Exception{
 
    public MyArraySizeException(String message, int N){
        super(message);
    }
}
class MyArrayDataException extends Exception{
	int i, j;
	public MyArrayDataException(int i, int j){
		this.i = i;
		this.j = j;
	}
}


