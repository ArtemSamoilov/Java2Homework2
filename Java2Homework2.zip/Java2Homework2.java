/**
 * Java 2 Homework 2
 *
 * @author Artem Samoilov
 * @version dated Dec 24, 2017
 * @link 
 */

import java.io.*;

class Java2Homework2{
	
	static int sum = 0;

	public static void main(String[] args) {
		
		int a = 2;
		int b = 3;
		
		String[][] arr = {{"1", "2", "5"}, {"4", "8", "16"}};
        arr[1][2] = "A";
		
		try{
			if(a != 4 || b != 4){
			    throw new ArrayIndexOutOfBoundsException("Matrix has wrong dimensions");
			}
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println(e);
		}
		
		try{
			arrCheck(arr, a, b);
		}catch(NumberFormatException e){
			System.out.println(e);
		}		
		
		System.out.println("Sum: " + sum);
		
	}

	public static void arrCheck(String[][] arr, int a, int b){
		
		for(int i = 0; i < a; i++){
			for(int j = 0; j < b; j++){
				try{
					sum += Integer.parseInt(arr[i][j]);
				}catch (Exception e) {
					throw new NumberFormatException("Convertion failed at: " + i + "; " + j);
				}
			}
		}
		
	}
}