/**
 * Java 2 Homework 6*
 * Class HelloClient: connect and get hello from server
 *
 * @author Artem Samoilov
 * @version dated Jan 14, 2018
 * @link 
 * Не знаю, правильно ли, но когда я сменил 1024 на 1023, у меня стала появляться указанная в задании ошибка :)
 */
import java.net.*;
import java.io.*;

class HelloClient {

    public static void main(String[] args) {
        new HelloClient();
    }

    HelloClient() {
        try (Socket socket = new Socket("35.157.116.164", 1023);
            BufferedReader reader =
                new BufferedReader(
                    new InputStreamReader(socket.getInputStream()))) {

            System.out.println(
                reader.readLine());

        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}