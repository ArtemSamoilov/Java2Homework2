/**
 * Java. Chatter: simple chatbot
 *
 * @author Artem Samoilov
 * @version dated Dec 29, 2017
 * @link
 */
import java.util.*;
import java.io.PrintStream;
import java.util.regex.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;

class SimpleChatBot extends JFrame implements ActionListener {

    final String TITLE_OF_PROGRAM = "Chatter: simple chatbot";
    final int START_LOCATION = 200;
    final int WINDOW_WIDTH = 350;
    final int WINDOW_HEIGHT = 450;
    final String CHB_AI = "AI";
    final String BTN_ENTER = "Enter";

    JTextPane dialogue; // area for dialog
    JCheckBox ai;       // enable/disable AI
    JTextField message; // field for entering messages
    SimpleAttributeSet botStyle; // style bot text

    public static void main(String[] args) {
		new SimpleChatBot();
    }

    /**
     * Constructor:
     * Creating a window and all the necessary elements on it
     */
    SimpleChatBot() {
		System.setProperty("console.encoding","Cp866");
        setTitle(TITLE_OF_PROGRAM);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(START_LOCATION, START_LOCATION, WINDOW_WIDTH, WINDOW_HEIGHT);
        // area for dialog
        dialogue = new JTextPane();
        dialogue.setEditable(false);
        dialogue.setContentType("text/html");
        JScrollPane scrollBar = new JScrollPane(dialogue);
        // style for bot messages
        botStyle = new SimpleAttributeSet();
        StyleConstants.setItalic(botStyle, true);
        StyleConstants.setForeground(botStyle, Color.blue);
        //StyleConstants.setAlignment(botStyle, StyleConstants.ALIGN_RIGHT);
        // panel for checkbox, message field and button
        JPanel bp = new JPanel();
        bp.setLayout(new BoxLayout(bp, BoxLayout.X_AXIS));
        ai = new JCheckBox(CHB_AI);
        ai.doClick();
        message = new JTextField();
        message.addActionListener(this);
        JButton enter = new JButton(BTN_ENTER);
        enter.addActionListener(this);
        // adding all elements to the window
        bp.add(ai);
        bp.add(message);
        bp.add(enter);
        add(BorderLayout.CENTER, scrollBar);
        add(BorderLayout.SOUTH, bp);
        setVisible(true);
        //sbot = new SimpleBot(); // creating bot object
    }


    /**
     * Listener of events from message field and enter button
     */
    @Override
    public void actionPerformed(ActionEvent event) {
        if (message.getText().trim().length() > 0) {
            try {
                StyledDocument doc = dialogue.getStyledDocument();
                doc.insertString(doc.getLength(), message.getText() + "\n", 
                    new SimpleAttributeSet());
            } catch(Exception e) { }
        }
        message.setText("");
        message.requestFocusInWindow();
    }
}

class DrawGraphs extends JFrame implements KeyListener {

    final String TITLE_OF_PROGRAM = "Drawing graphs of simple functions";
    final int START_LOCATION = 200;
    final int WINDOW_WIDTH = 550;
    final int WINDOW_HEIGTH = 350;
    final int LEFT = 37;    // key codes
    final int UP = 38;
    final int RIGHT = 39;
    final int DOWN = 40;
    final int SIN = 83;     // for choosing function
    final int COS = 67;
    final int TAN = 84;

    Canvas canvas; // JPanel for painting
    float stretchX = 1.2f;
    int stretchY = 75;
    int typeGraph = SIN;    // default type of function

    public static void main(String[] args) {
        new DrawGraphs();
    }

    DrawGraphs() {
        setTitle(TITLE_OF_PROGRAM);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setBounds(START_LOCATION, START_LOCATION, WINDOW_WIDTH, WINDOW_HEIGTH);
        setResizable(false);
        canvas = new Canvas();
        canvas.setBackground(Color.white);
        add(BorderLayout.CENTER, canvas);
        addKeyListener(this);
        setVisible(true);
    }

    @Override
    public void keyPressed(KeyEvent event) { }

    @Override
    public void keyTyped(KeyEvent event) { }

    @Override
    public void keyReleased(KeyEvent event) {
        switch (event.getKeyCode()) {
            case LEFT: stretchX -= 0.1;
                canvas.repaint();
                break;
            case RIGHT: stretchX += 0.1;
                canvas.repaint();
                break;
            case UP: stretchY += 5;
                canvas.repaint();
                break;
            case DOWN: stretchY -= 5;
                canvas.repaint();
                break;
            case SIN:
            case COS:
            case TAN: typeGraph = event.getKeyCode();
                canvas.repaint();
                break;
            default:
                System.out.println(event.getKeyCode());
        }
    }

    class Canvas extends JPanel { // for painting
        @Override
        public void paint(Graphics g) {
            super.paint(g);

            // get the real size
            Dimension d = this.getSize();
            int width = (int) d.getWidth();
            int height = (int) d.getHeight();

            // drawing coordinate lines
            g.drawLine(5, height / 2, width - 6, height / 2);
            g.drawLine(width / 2, 5, width / 2, height - 6);

            // draving arrows ��
            g.drawLine(width - 6, height / 2, width - 6 - 7, height / 2 - 3);
            g.drawLine(width - 6, height / 2, width - 6 - 7, height / 2 + 3);

            // draving arrows Y
            g.drawLine(width / 2, 5, width / 2 - 3, 5 + 7);
            g.drawLine(width / 2, 5, width / 2 + 3, 5 + 7);

            // drawing name of coordinates
            g.drawString("X", width - 15, height / 2 - 8);
            g.drawString("Y", width / 2 - 15, 20);
            g.drawString("Sin | Cos | Tan", 10, height - 15);

            // converting degrees to radians
            // radians = degrees * Math.PI/180

            g.setColor(Color.blue);
            for (int x = -(width / 2 - 10), y = 0; x < width /2 - 10; x++) {
                double radian = Math.toRadians(x) * stretchX;
                switch (typeGraph) {
                    case SIN:
                        g.drawString("SIN", 10, 20);
                        y = (int) (Math.sin(radian) * stretchY);
                        break;
                    case COS:
                        g.drawString("COS", 10, 20);
                        y = (int) (Math.cos(radian) * stretchY);
                        break;
                    case TAN:
                        g.drawString("TAN", 10, 20);
                        y = (int) (Math.tan(radian) * stretchY);
                }
                g.drawRect(x + width / 2, y + height / 2, 0, 0);
            }
        }
    }
}