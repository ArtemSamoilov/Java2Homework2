/**
 * Java 2 Homework 2
 *
 * @author Artem Samoilov
 * @version dated Dec 29, 2017
 * @link 
 */

import java.io.*;
import java.util.ArrayList;

public class Java2HMW3{
	
	static final String FILE_NAME = "text.txt";
	
	public static void main(String[] argc){
		task1();
		task2();		
	}
	
	static void task1(){
		//Task 1
		
		ArrayList<String> list = new ArrayList<String>();
        StringBuffer buffer = new StringBuffer();
		
		System.out.println("Task #1\n");
		
        
		try (BufferedReader reader = new BufferedReader(
                new FileReader(FILE_NAME))) {

            while (reader.ready()){
				list.add(reader.readLine());
			}

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
		
		System.out.println("LinkedList: " + list);
		
		int length = list.size();
		
		System.out.print("\nUnique elements: ");
		
		for(int i = 0; i < length; i++){
			int sum = 0;
			for(int j = 0; j < length; j++){
				if(list.get(i).equals(list.get(j)))
					sum ++;
			}
			if(sum == 1)
				System.out.print(list.get(i) + " ");
		}
		
		System.out.println("\n");
		
		for(int i = 0; i < length; i++){
			int sum = 0;
			int pos = 0;

			for(int j = 0; j < length; j++){
				if(list.get(i).equals(list.get(j))){
					sum++;
					if(i > j)
						pos++;
				}	
			}
			if(pos == 0)
			    System.out.println(list.get(i) + ": " + sum);
		}
	}
	
	static void task2(){
		// Task 2
		
		System.out.println("\nTask #2\n");
		
		ArrayList<String> name = new ArrayList<String>();
		ArrayList<Integer> number = new ArrayList<Integer>();
		
		name.add("Kuragin");
		name.add("Rostov");
		name.add("Bolkonsky");
		name.add("Tushin");
		name.add("Kuragin");
		name.add("Rostov");
		name.add("Besuhov");
		name.add("Rostov");
		
		number.add(77745611);
		number.add(49745611);
		number.add(11745616);
		number.add(77709461);
		number.add(77739801);
		number.add(78469233);
		number.add(77575384);
		number.add(77798230);
		
		try{
			FileWriter file = new FileWriter("catalog.txt");
			BufferedWriter buffer = new BufferedWriter(file);
			for(int i = 0; i < name.size(); i++){
				buffer.write(name.get(i) + ": " + number.get(i));
				buffer.newLine();
			}
			buffer.close();			
		}catch(IOException ex){
			System.out.println("Reconsider your input");
		}
		
		String name1 = name.get(1);
		String name2 = name.get(4);
		String name3 = name.get(6);
		
		System.out.print(name1 + ": ");
		for(int i = 0; i < name.size(); i++){
			if(name1 == name.get(i)){
				System.out.print(number.get(i) + " ");
			}
		}
		
		System.out.print("\n" + name2 + ": ");
		for(int i = 0; i < name.size(); i++){
			if(name2 == name.get(i)){
				System.out.print(number.get(i) + " ");
			}
		}
		
		System.out.print("\n" + name3 + ": ");
		for(int i = 0; i < name.size(); i++){
			if(name3 == name.get(i)){
				System.out.print(number.get(i) + " ");
			}
		}
	}
}